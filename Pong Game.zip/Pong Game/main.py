import turtle
import random
# screen_setup
screen = turtle.Screen()
screen.title("ping pong by sherif ahmed")
# color of the screen
screen.bgcolor("black")
# set up the height and width of the screen
screen.setup(width=800, height=600)
# stops the window form update Automatically
screen.tracer(0)

# paddle1 #pleyer1
paddle1 = turtle.Turtle()
# speed of the animation
paddle1.speed(0)
# shape of the object
paddle1.shape("square")
paddle1.shapesize(stretch_wid=5, stretch_len=1)
# color of the object
paddle1.color("red")
paddle1.penup()
paddle1.goto(-350, 0)

# paddle2 #pleyer2
paddle2 = turtle.Turtle()
# speed of the animation
paddle2.speed(0)
# shape of the object
paddle2.shape("square")
paddle2.shapesize(stretch_wid=5, stretch_len=1)
# color of the object
paddle2.color("yellow")
paddle2.penup()
paddle2.goto(350, 0)

# ball
ball = turtle.Turtle()
ball.speed(0)
# shape of the object
ball.shape("circle")
# color of the object
ball.color("white")
ball.penup()
ball.goto(0, 0)
ball.dx = 0.2
ball.dy = -0.2
# functions paddle1
def paddle1_up():
    y = paddle1.ycor()
    y += 30
    paddle1.sety(y)

def paddle1_down():
    y = paddle1.ycor()
    y -= 30
    paddle1.sety(y)

# functions paddle2

def paddle2_up():
    y = paddle2.ycor()
    y += 30
    paddle2.sety(y)

def paddle2_down():
    y = paddle2.ycor()
    y -= 30
    paddle2.sety(y)


# Keyboard operations
screen.listen()
screen.onkeyrelease(paddle1_up, "w")
screen.onkeyrelease(paddle1_down, "s")
screen.onkeyrelease(paddle2_up, "Up")
screen.onkeyrelease(paddle2_down, "Down")
# score
score1 = 0
score2 = 0
score = turtle.Turtle()
score.speed(0)
score.color("white")
score.penup()
score.hideturtle()
score.goto(0, 260)
# main game loop
while True:
    screen.update()
    # move the ball
    ball.setx(ball.xcor()+ball.dx)
    ball.sety(ball.ycor()+ball.dy)
    # border check
    if ball.ycor() > 290:
        ball.sety(290)
        ball.dy *= -1

    if ball.ycor() < -290:
        ball.sety(-290)
        ball.dy *= -1

    if ball.xcor() > 390:
        ball.goto(0, 0)
        ball.dx *= -1
        score1 += 1

        score.write("Player 1: {} Player2: {}".format(score1, score2), align="center", font=("Courier", 24, "normal"))


    if ball.xcor() < -390:
        ball.goto(0, 0)
        ball.dx *= -1
        ball.goto(0, 0)
        ball.dx *= -1
        score2 += 1
        score.clear()
        score.write("Player 1: {}, Player2: {}".format(score1, score2), align="center", font=("Courier", 24, "normal"))
        if(score2>score1):
         print("player2:متلعب يا نوب")
    # Collisions

    if (ball.xcor() > 340 and ball.xcor() < 350) and (ball.ycor() < paddle2.ycor() + 40 and ball.ycor() > paddle2.ycor() - 40):
        ball.setx(340)
        ball.dx *= -1


    if (ball.xcor() < -340 and ball.xcor() > -350) and (ball.ycor() < paddle1.ycor() + 40 and ball.ycor() > paddle1.ycor() - 40):
        ball.setx(-340)
        ball.dx *= -1